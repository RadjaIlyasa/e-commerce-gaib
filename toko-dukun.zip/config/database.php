
<?php

$isLocal = in_array($_SERVER['HTTP_HOST'] ?? '', [
    'localhost',
    '127.0.0.1'
]);

if ($isLocal) {
    // Database lokal XAMPP
    $host = 'localhost';
    $dbname = 'pasar_gaib';
    $username = 'root';
    $password = '';
} else {
    // Database hosting InfinityFree
    $host = 'sql113.infinityfree.com';
    $dbname = 'if0_43321141_pasar_gaib';
    $username = 'if0_43321141';
    $password = '04110EnamM';
}

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch (PDOException $e) {
    error_log($e->getMessage());
    http_response_code(500);
    exit('Koneksi database gagal. Periksa konfigurasi server.');
}
